power base 0 = 1
power base exp = base * power base (exp-1)

main = do
    print(power 2 4)
    print(power 2 5)
    print(power 2 6)
    print(power 3 2)
    print(power 3 3)