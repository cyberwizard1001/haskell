--Nirmal K--
--Print address--

main = do
    putStrLn "Enter your address: "
    x <- getLine
    print("You address: " ++ x)